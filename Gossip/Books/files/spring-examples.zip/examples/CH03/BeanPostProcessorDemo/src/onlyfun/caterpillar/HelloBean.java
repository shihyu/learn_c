package onlyfun.caterpillar; 

public class HelloBean { 
    private String helloWord; 
    
    public void setHelloWord(String helloWord) { 
        this.helloWord = helloWord; 
    } 
    
    public String getHelloWord() { 
        return helloWord; 
    } 
}