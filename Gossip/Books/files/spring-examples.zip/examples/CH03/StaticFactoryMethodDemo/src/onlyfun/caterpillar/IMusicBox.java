package onlyfun.caterpillar;

public interface IMusicBox {
    public void play();
}
