package onlyfun.caterpillar.web;

public class LoginForm {
    private String username;
    private String passwd;
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getPasswd() {
        return passwd;
    }
}
