package onlyfun.caterpillar;

public class UserChanger {
    public String getChangedName(String name) {
        return name.toUpperCase();
    }
}
