package onlyfun.caterpillar;

public class WeekForm {
    private String weekNumber;
    
    public void setWeekNumber(String weekNumber) {
        this.weekNumber = weekNumber;
    }

    public String getWeekNumber() {
        return weekNumber;
    }
}
