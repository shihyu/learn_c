package onlyfun.caterpillar;

public interface ISomeService { 
    public String doSomeService(String some);
    public int doOtherService(int other);
} 
