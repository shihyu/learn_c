package onlyfun.caterpillar;

import java.util.TimerTask;

public class DemoTask extends TimerTask {
    public void run() {
        System.out.println("Task is executed.");
    }
}
