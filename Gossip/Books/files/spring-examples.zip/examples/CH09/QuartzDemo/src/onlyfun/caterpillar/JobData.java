package onlyfun.caterpillar;

import java.util.Date;

public class JobData {
    public String getData() {
        return "Data from " + new Date().toString();
    }
}
