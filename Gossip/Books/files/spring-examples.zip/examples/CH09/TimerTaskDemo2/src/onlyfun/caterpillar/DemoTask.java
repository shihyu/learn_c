package onlyfun.caterpillar;

public class DemoTask {
    public void execute() {
        System.out.println("Task is executed.");
    }
}