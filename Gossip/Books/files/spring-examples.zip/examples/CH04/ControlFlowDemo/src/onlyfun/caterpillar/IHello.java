package onlyfun.caterpillar;

public interface IHello {
    public void helloNewbie(String name);
    public void helloMaster(String name);
}