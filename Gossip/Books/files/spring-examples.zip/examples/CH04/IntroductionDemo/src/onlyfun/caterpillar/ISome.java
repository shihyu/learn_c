package onlyfun.caterpillar;

public interface ISome {
    public void doSome();
}