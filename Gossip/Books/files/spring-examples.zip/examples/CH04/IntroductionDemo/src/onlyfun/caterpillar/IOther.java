package onlyfun.caterpillar; 

public interface IOther {  
    public void doOther();
}