package onlyfun.caterpillar;

public interface ISome {
    public void setSome(String some);
    public String getSome();
}