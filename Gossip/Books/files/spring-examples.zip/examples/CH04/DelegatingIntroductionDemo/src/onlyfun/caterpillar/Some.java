package onlyfun.caterpillar;

public class Some implements ISome { 
    private String some;
    
    public void setSome(String some) {
        this.some = some;
    }
    
    public String getSome() {
        return some;
    }
}