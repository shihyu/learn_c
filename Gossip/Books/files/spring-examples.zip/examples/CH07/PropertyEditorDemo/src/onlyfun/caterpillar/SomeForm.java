package onlyfun.caterpillar;

public class SomeForm {
    private User user; 
    
    public void setUser(User user) { 
        this.user = user;
    }
    
    public User getUser() { 
        return user;
    }
}
