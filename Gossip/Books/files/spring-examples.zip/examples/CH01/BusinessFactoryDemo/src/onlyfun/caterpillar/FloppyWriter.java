package onlyfun.caterpillar;

public class FloppyWriter implements IDeviceWriter {
	public void saveToDevice() {
		System.out.println("�x�s�ܳn�о��K");
	}
}
