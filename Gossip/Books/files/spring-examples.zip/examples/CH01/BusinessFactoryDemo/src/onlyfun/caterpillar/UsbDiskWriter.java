package onlyfun.caterpillar;

public class UsbDiskWriter implements IDeviceWriter {
	public void saveToDevice() {
		System.out.println("�x�s���H���СK");
	}
}
