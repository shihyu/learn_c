package onlyfun.caterpillar;

public interface IDeviceWriter {
	public void saveToDevice();
}
