package cc.openhome;

public class Client {
    public final String ip;
    public final String name;
    public Client(String ip, String name) {
        this.ip = ip;
        this.name = name;
    }
}
