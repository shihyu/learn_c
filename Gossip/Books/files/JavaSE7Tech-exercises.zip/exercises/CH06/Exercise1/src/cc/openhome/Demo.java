package cc.openhome;

public class Demo {
    public static void main(String[] args) {
        ArrayList list = new ArrayList();
        list.add("Justin");
        list.add("Monica");
        list.add("Irene");
        System.out.println(list);
    }
}
