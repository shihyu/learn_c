package cc.openhome.tag;

import javax.servlet.jsp.PageContext;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println(PageContext.APPLICATION);
    }

}
